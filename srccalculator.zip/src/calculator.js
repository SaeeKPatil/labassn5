import React, { useState } from 'react';
import './Calculator.css'; // External CSS for styling

const Calculator = () => {
  const [input, setInput] = useState('');
  const [error, setError] = useState(false);

  const handleClick = (value) => {
    setInput((prev) => prev + value);
    setError(false);
  };

  const handleClear = () => {
    setInput('');
    setError(false);
  };

  const handleEvaluate = () => {
    try {
      setInput(eval(input).toString());
    } catch {
      setError(true);
      setInput('');
    }
  };

  return (
    <div className="calculator">
      <input type="text" value={error ? 'Error' : input} readOnly className="calculator-display" />
      <div className="calculator-buttons">
        {['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '0', '.', '=', '+'].map((btn) => (
          <button key={btn} onClick={btn === '=' ? handleEvaluate : () => handleClick(btn)}>{btn}</button>
        ))}
        <button className="clear-btn" onClick={handleClear}>C</button>
      </div>
    </div>
  );
};

export default Calculator;
