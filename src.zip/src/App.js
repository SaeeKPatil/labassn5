import React from 'react';
import Form from './Form'; // Ensure Form is imported correctly

function App() {
  return (
    <div className="App">
      <h1>React Form Example</h1>
      <p>Please fill in the form below:</p>
      <Form />  {/* Renders the Form component */}
    </div>
  );
}

export default App;

