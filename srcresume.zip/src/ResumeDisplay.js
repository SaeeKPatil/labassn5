import React from 'react';

const ResumeDisplay = ({ resumeData }) => {
  return (
    <div className="resume-display-container">
      <h2>Generated Resume</h2>
      <div className="resume-section">
        <h3>Professional Summary</h3>
        <p>{resumeData.professionalSummary}</p>
      </div>
      <div className="resume-section">
        <h3>Education Qualifications</h3>
        <p>{resumeData.education}</p>
      </div>
      <div className="resume-section">
        <h3>Skills</h3>
        <p>{resumeData.skills}</p>
      </div>
      <div className="resume-section">
        <h3>Career Objective</h3>
        <p>{resumeData.careerObjective}</p>
      </div>
      <div className="resume-section">
        <h3>Experience & Internships</h3>
        <p>{resumeData.experience}</p>
      </div>
      <div className="resume-section">
        <h3>Skills & Achievements</h3>
        <p>{resumeData.achievements}</p>
      </div>
    </div>
  );
};

export default ResumeDisplay;
