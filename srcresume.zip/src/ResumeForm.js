import React, { useState } from 'react';
import ResumeDisplay from './ResumeDisplay'; // Import the ResumeDisplay component
import './ResumeForm.css';

const ResumeForm = () => {
  const [resumeData, setResumeData] = useState({
    professionalSummary: '',
    education: '',
    skills: '',
    careerObjective: '',
    experience: '',
    achievements: '',
  });

  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');
  const [submitted, setSubmitted] = useState(false); // State to track submission

  const handleChange = (e) => {
    setResumeData({
      ...resumeData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = {};

    // Validation checks
    if (!resumeData.professionalSummary) newErrors.professionalSummary = 'Professional Summary is required';
    if (!resumeData.education) newErrors.education = 'Education details are required';
    if (!resumeData.skills) newErrors.skills = 'Skills are required';
    if (!resumeData.careerObjective) newErrors.careerObjective = 'Career Objective is required';
    if (!resumeData.experience) newErrors.experience = 'Experience/Internships are required';
    if (!resumeData.achievements) newErrors.achievements = 'Achievements are required';

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      setSuccessMessage('Resume submitted successfully!');
      setSubmitted(true); // Set submitted to true to show the resume
    } else {
      setSuccessMessage('');
    }
  };

  return (
    <div className="resume-form-container">
      {submitted ? (
        <ResumeDisplay resumeData={resumeData} /> // Render the resume display
      ) : (
        <>
          <h2>Resume Builder</h2>
          {successMessage && <p className="success-message">{successMessage}</p>}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="professionalSummary">Professional Summary:</label>
              <textarea
                name="professionalSummary"
                value={resumeData.professionalSummary}
                onChange={handleChange}
                rows="4"
                placeholder="Summarize your professional experience..."
              />
              {errors.professionalSummary && <p className="error-message">{errors.professionalSummary}</p>}
            </div>

            <div className="form-group">
              <label htmlFor="education">Education Qualifications:</label>
              <textarea
                name="education"
                value={resumeData.education}
                onChange={handleChange}
                rows="4"
                placeholder="List your educational qualifications..."
              />
              {errors.education && <p className="error-message">{errors.education}</p>}
            </div>

            <div className="form-group">
              <label htmlFor="skills">Skills (Academic & Non-Academic):</label>
              <textarea
                name="skills"
                value={resumeData.skills}
                onChange={handleChange}
                rows="4"
                placeholder="Mention your skills (both academic and non-academic)..."
              />
              {errors.skills && <p className="error-message">{errors.skills}</p>}
            </div>

            <div className="form-group">
              <label htmlFor="careerObjective">Career Objective:</label>
              <textarea
                name="careerObjective"
                value={resumeData.careerObjective}
                onChange={handleChange}
                rows="4"
                placeholder="State your career objective..."
              />
              {errors.careerObjective && <p className="error-message">{errors.careerObjective}</p>}
            </div>

            <div className="form-group">
              <label htmlFor="experience">Experience & Internships:</label>
              <textarea
                name="experience"
                value={resumeData.experience}
                onChange={handleChange}
                rows="4"
                placeholder="List your experience and internships..."
              />
              {errors.experience && <p className="error-message">{errors.experience}</p>}
            </div>

            <div className="form-group">
              <label htmlFor="achievements">Skills & Achievements:</label>
              <textarea
                name="achievements"
                value={resumeData.achievements}
                onChange={handleChange}
                rows="4"
                placeholder="Mention your skills and notable achievements..."
              />
              {errors.achievements && <p className="error-message">{errors.achievements}</p>}
            </div>

            <button type="submit" className="submit-btn">Submit</button>
          </form>
        </>
      )}
    </div>
  );
};

export default ResumeForm;
